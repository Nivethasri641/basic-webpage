<?php 
session_start();
include("connection.php");
include("functions.php");

$user_data = check_login($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>myRAYMOND.com</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
        }

        header {
            background-color: #000;
            color: #fff;
            padding: 20px 0;
            text-align: center;
        }

        nav {
            background-color: #333;
            color: #fff;
            padding: 10px 0;
            text-align: center;
        }

        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
        }

        nav ul li {
            display: inline;
            margin: 0 10px;
        }

        nav ul li a {
            color: #fff;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        nav ul li a:hover {
            background-color: #555;
        }

        main {
            padding: 20px;
            text-align: center;
            background-color: rgba(255, 255, 255, 0.9); 
            border-radius: 10px; 
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); 
        }

        marquee {
            display: block;
            margin: 20px auto;
            overflow: hidden;
        }

        marquee img {
            width: 600px;
            height: 450px;
            margin: 0 10px;
        }

        .user-content {
            margin-bottom: 20px;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .greeting {
            margin-top: 20px;
            text-align: center;
            font-size: 24px;
            color: #666;
        }

        .logout-btn {
            display: block;
            width: 100px;
            margin: 20px auto;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            text-align: center;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .logout-btn:hover {
            background-color: #0056b3;
        }

        #home-link {
            position: absolute;
            top: 10px;
            right: 10px;
            text-decoration: none;
            color: white;
            font-size: 14px;
            padding: 5px 10px;
            background-color: black;
            border-radius: 5px;
        }

        #home-link:hover {
            background-color: #333;
        }
    </style>
</head>
<body>
    <header>
        <h1>myRAYMOND.com</h1>
        <?php if(isset($user_data['user_name'])): ?>
            <a id="home-link" href="logout.php">Logout</a>
        <?php else: ?>
            <a id="home-link" href="login.php">Login</a>
        <?php endif; ?>
    </header>
    <nav>
        <ul>
            <li><a href="raymond.php">HOME</a></li>
            <li><a href="about.html">ABOUT US</a></li>
            <li><a href="branch.html">BRANCHES</a></li>
            <li><a href="brand.html">BRANDS</a></li>
            <li><a href="style.html">STYLES</a></li>
            <li><a href="offer.html">OFFERS</a></li>
            <li><a href="cont.html">CONTACT</a></li>
            <li><a href="signup.php">SIGN IN</a></li>
            <?php if(!isset($user_data['user_name'])): ?>
                <li><a href="login.php">LOGIN</a></li>
            <?php endif; ?>
        </ul>
    </nav>
    <main>
        <?php if(isset($user_data['user_name'])): ?>
            <div class="user-content">
                <div class="greeting">
                    Hello, <?php echo htmlspecialchars($user_data['user_name']); ?>!
                </div>
                <a class="logout-btn" href="logout.php">Logout</a>
            </div>
        <?php endif; ?>
        <marquee behavior="scroll" direction="left">
            <img src="t1.jpg" alt="smile">
            <img src="t2.jpg" alt="smile">
            <img src="o1.jpg" alt="smile">
            <img src="ccc.jpg" alt="smile">
        </marquee>
        <h2>Welcome to myRAYMOND.com</h2>
        <p>Explore our latest collections and discover exclusive offers.</p>
    </main>
</body>
</html>
