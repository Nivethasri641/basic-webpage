<?php 
session_start();

include("connection.php");
include("functions.php");

$user_data = check_login($con);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Our Website</title>
    <style>
        #home-link {
            position: absolute;
            top: 10px;
            right: 10px;
            text-decoration: none;
            color: white;
            font-size: 14px;
            padding: 5px 10px;
            background-color: black;
            border-radius: 5px;
        }

        #home-link:hover {
            background-color: #333;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #333;
            text-align: center;
        }

        .greeting {
            margin-top: 20px;
            text-align: center;
            font-size: 24px;
            color: #666;
        }

        .logout-btn {
            display: block;
            width: 100px;
            margin: 20px auto;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            text-align: center;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .logout-btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
<a id="home-link" href="raymond.html">Home</a>
<div class="container">
    <h1>Welcome to Our Website</h1>
    <div class="greeting">
        Hello, <?php echo isset($user_data['user_name']) ? $user_data['user_name'] : 'Guest'; ?>!
    </div>
    <a class="logout-btn" href="logout.php">Logout</a>
</div>
</body>
</html>
